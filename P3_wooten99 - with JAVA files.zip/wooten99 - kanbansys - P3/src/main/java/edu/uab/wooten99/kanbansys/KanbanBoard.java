/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.uab.wooten99.kanbansys;
import java.util.HashMap;

/**
 *
 * @author Cole
 */

//Create the concept of a KanbanBoard which models a Kanban Board, as a minimum, it should
//Collect all Kanban Cards into an HashMap using UID as the key
//Find all Kanban cards of a particular state

public class KanbanBoard {  
    
    //use hashmap to retrieve kanban card
    public String getUid() {
    return (KanbanCard.string[UID].toString();
  }
   
   myHashmap<String> List = HashMap<kanban, string> ;
   get KanbanCard.UID
    
   
           
//use scan or iterator to retrieve specific kanban states
           
    
}
   
    



