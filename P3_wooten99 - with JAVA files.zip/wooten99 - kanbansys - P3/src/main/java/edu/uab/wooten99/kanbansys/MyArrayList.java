/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//Change Kanban card to use an ArrayList

package edu.uab.wooten99.kanbansys;

import java.util.ArrayList;

/**
 *
 * @author Cole
 */
public class MyArrayList {

  public static void ArrayList(String[] args) {
      
      
      // THIS IS A TEST CLASS AND IS NOT IN USE IN THE FINAL ITERATION OF P3 //

      
    ArrayList<String> State = new ArrayList<String>() ;
    
    State.add("BACKLOG");
    State.add("DESIGN");
    State.add("BUILD");
    State.add("TEST");
    State.add("RELEASE");
    State.add("DONE");
    State.add("ABANDONED");
    
    State.set(1,"BACKLOG");
    State.set(2,"DESIGN");
    State.set(3,"BUILD");
    State.set(4,"TEST");
    State.set(5,"RELEASE");
    State.set(6,"DONE");
    State.set(7,"ABANDONED");


    
    System.out.println(State);
    
    
  }
}
// old statelist

// String[] stateList = {"BACKLOG", "DESIGN", "BUILD", "TEST", "RELEASE", "DONE", "ABANDONED"};