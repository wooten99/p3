/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.uab.wooten99.kanbansys;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Cole
 */
public class StateFieldTest {
    
    public StateFieldTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of get method, of class StateField.
     */
    @Test
    public void testGet() {
        System.out.println("get");
        StateField instance = null;
        String expResult = "";
        String result = instance.get();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class StateField.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        StateField instance = null;
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of valueCompareTo method, of class StateField.
     */
    @Test
    public void testValueCompareTo() {
        System.out.println("valueCompareTo");
        Field f = null;
        StateField instance = null;
        int expResult = 0;
        int result = instance.valueCompareTo(f);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of newField method, of class StateField.
     */
    @Test
    public void testNewField() {
        System.out.println("newField");
        Object newValue = null;
        StateField instance = null;
        Field expResult = null;
        Field result = instance.newField(newValue);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
