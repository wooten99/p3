/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.uab.wooten99.kanbansys;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Cole
 */
public class DateFieldTest {
    
    public DateFieldTest() {
    }

    @org.junit.jupiter.api.BeforeAll
    public static void setUpClass() throws Exception {
    }

    @org.junit.jupiter.api.AfterAll
    public static void tearDownClass() throws Exception {
    }

    @org.junit.jupiter.api.BeforeEach
    public void setUp() throws Exception {
    }

    @org.junit.jupiter.api.AfterEach
    public void tearDown() throws Exception {
    }
  

    /**
     * Test of get method, of class DateField.
     */
    @org.junit.jupiter.api.Test
    public void testGet() {
        System.out.println("get");
        DateField instance = null;
        KanbanDate expResult = null;
        KanbanDate result = instance.get();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class DateField.
     */
    @org.junit.jupiter.api.Test
    public void testToString() {
        System.out.println("toString");
        DateField instance = null;
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of valueCompareTo method, of class DateField.
     */
    @org.junit.jupiter.api.Test
    public void testValueCompareTo() {
        System.out.println("valueCompareTo");
        Field f = null;
        DateField instance = null;
        int expResult = 0;
        int result = instance.valueCompareTo(f);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of newField method, of class DateField.
     */
    @org.junit.jupiter.api.Test
    public void testNewField() {
        System.out.println("newField");
        Object newValue = null;
        DateField instance = null;
        Field expResult = null;
        Field result = instance.newField(newValue);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
