/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.uab.wooten99.kanbansys;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Cole
 */
public class FieldTest {
    
    public FieldTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getName method, of class Field.
     */
    @Test
    public void testGetName() {
        System.out.println("getName");
        Field instance = null;
        String expResult = "";
        String result = instance.getName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of newField method, of class Field.
     */
    @Test
    public void testNewField() {
        System.out.println("newField");
        Object newValue = null;
        Field instance = null;
        Field expResult = null;
        Field result = instance.newField(newValue);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isName method, of class Field.
     */
    @Test
    public void testIsName() {
        System.out.println("isName");
        String name = "";
        Field instance = null;
        boolean expResult = false;
        boolean result = instance.isName(name);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class Field.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Field instance = null;
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTaggedString method, of class Field.
     */
    @Test
    public void testGetTaggedString() {
        System.out.println("getTaggedString");
        Field instance = null;
        String expResult = "";
        String result = instance.getTaggedString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getType method, of class Field.
     */
    @Test
    public void testGetType() {
        System.out.println("getType");
        Field instance = null;
        String expResult = "";
        String result = instance.getType();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of get method, of class Field.
     */
    @Test
    public void testGet() {
        System.out.println("get");
        Field instance = null;
        Object expResult = null;
        Object result = instance.get();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of compareTo method, of class Field.
     */
    @Test
    public void testCompareTo() {
        System.out.println("compareTo");
        Field f = null;
        Field instance = null;
        int expResult = 0;
        int result = instance.compareTo(f);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of valueCompareTo method, of class Field.
     */
    @Test
    public void testValueCompareTo() {
        System.out.println("valueCompareTo");
        Field f = null;
        Field instance = null;
        int expResult = 0;
        int result = instance.valueCompareTo(f);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    public class FieldImpl extends Field {

        public FieldImpl() {
            super("", "");
        }

        public Field newField(Object newValue) {
            return null;
        }

        public String toString() {
            return "";
        }

        public Object get() {
            return null;
        }

        public int valueCompareTo(Field f) {
            return 0;
        }
    }
    
}
